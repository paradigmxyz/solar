| case | solar | lean | expect | exit | match | class | kind | stage_ok | replay | producer | certify.log sha256 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| clampwrongspec-r2 | 65d87ab354 | 334d1d924f | 1 | 3 | **NO** | semantic | DONE | no | none | ok | 84ef89181c8cdb6fa6d80f5c65153bb56cf6797fceb8f35f1d4ffdeec2cc50ce |
| control-flag | 65d87ab354 | 334d1d924f | 0 | 0 | yes | control | DONE | yes | skipped-c1 | ok | 738243ed3277e374e94425c0a516c05df4eba180d22a14e1f1c31ad6490d3a16 |
| control-flagrenamed | 65d87ab354 | 334d1d924f | 0 | 0 | yes | control | DONE | yes | skipped-c1 | ok | f21da8fd248790117b1d09db66cd970bc049ef4428a9346ff34bf467b31c2e97 |
| control-siblingok | 65d87ab354 | 334d1d924f | 0 | 0 | yes | control | DONE | yes | skipped-c1 | ok | e2ced86295feff202180632523d8d614776d993d58b6268e5efedf97b8770f18 |
| meterwrongspec | 65d87ab354 | 334d1d924f | 1 | 1 | yes | semantic | DONE | yes | none | ok | 3868ba639e43267d331a117680b8bb82015153641f68aeb77b34443b172ce87b |
| siblingfns-r2 | 65d87ab354 | 334d1d924f | 1 | 3 | **NO** | semantic | DONE | no | none | ok | c8cdca64f5a6414daa67b04905855efe567e420d0a907270aa3759b2755cc1e9 |

Control gate: PASS (control-flag ok, control-siblingok ok, control-flagrenamed ok)
Semantic rejections counted: 1 of 3: meterwrongspec
