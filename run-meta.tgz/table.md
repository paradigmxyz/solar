| case | solar | lean | expect | exit | match | class | kind | stage_ok | replay | producer | certify.log sha256 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| control-flag | 92c59b665b | 334d1d924f | 0 | 0 | yes | control | DONE | no | skipped-c1 | ok | b7cc8f1decb0c372b3486a0fd7f6be2c0a3507c76194d19df205baa42c50a044 |
| control-flagrenamed | 92c59b665b | 334d1d924f | 0 | 0 | yes | control | DONE | no | skipped-c1 | ok | a622e116f09c99fb52d26743139a12625f5933b5d99eaaad244fae8e96c68f28 |
| control-siblingok | 92c59b665b | 334d1d924f | 0 | 0 | yes | control | DONE | no | skipped-c1 | ok | d61fc3c077c962332f4531fff40a244d54a304a6c6404e096342a4228ccb1b38 |

Control gate: FAIL (control-flag no: independent --replay exit 'skipped-c1', control-siblingok no: independent --replay exit 'skipped-c1', control-flagrenamed no: independent --replay exit 'skipped-c1')
Semantic rejections counted: 0 of 0
