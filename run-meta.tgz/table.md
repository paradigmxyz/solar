| case | solar | lean | expect | exit | match | class | kind | stage_ok | replay | producer | certify.log sha256 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| control-flag | 65d87ab354 | 334d1d924f | 0 | 0 | yes | control | DONE | yes | skipped-c1 | ok | 738243ed3277e374e94425c0a516c05df4eba180d22a14e1f1c31ad6490d3a16 |
| control-flagrenamed | 65d87ab354 | 334d1d924f | 0 | 0 | yes | control | DONE | yes | skipped-c1 | ok | f21da8fd248790117b1d09db66cd970bc049ef4428a9346ff34bf467b31c2e97 |
| control-siblingok | 65d87ab354 | 334d1d924f | 0 | 0 | yes | control | DONE | yes | skipped-c1 | ok | e2ced86295feff202180632523d8d614776d993d58b6268e5efedf97b8770f18 |
| falseenv | 65d87ab354 | 334d1d924f | 3 | 3 | yes | failclosed | DONE | no | none | mismatch | 4e90464804ca03d596214a5a13a911e23ce8a3e770e5952fb862b4b5000a7e65 |
| flag-wrap | 65d87ab354 | 334d1d924f | 3 | 3 | yes | failclosed | DONE | yes | none | ok | b0742e79c1913143c1a742d8af5fb236d0d103831b96325f680c88e03c080dca |
| vacuoussecond-r2b | 65d87ab354 | 334d1d924f | 1 | 1 | yes | semantic | DONE | no | none | ok | 1ac10bf60ab45e2fdefb88257a6eda251dda045a9806eb51d387b4427271ef22 |

Control gate: PASS (control-flag ok, control-siblingok ok, control-flagrenamed ok)
Semantic rejections counted: 0 of 1
