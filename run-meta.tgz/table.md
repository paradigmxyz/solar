| case | solar | lean | expect | exit | match | class | kind | stage_ok | replay | producer | certify.log sha256 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| control-flag | 65d87ab354 | 334d1d924f | 0 | 0 | yes | control | DONE | yes | skipped-c1 | ok | 738243ed3277e374e94425c0a516c05df4eba180d22a14e1f1c31ad6490d3a16 |
| control-flagrenamed | 65d87ab354 | 334d1d924f | 0 | 0 | yes | control | DONE | yes | skipped-c1 | ok | f21da8fd248790117b1d09db66cd970bc049ef4428a9346ff34bf467b31c2e97 |
| control-siblingok | 65d87ab354 | 334d1d924f | 0 | 0 | yes | control | DONE | yes | skipped-c1 | ok | e2ced86295feff202180632523d8d614776d993d58b6268e5efedf97b8770f18 |
| initbroken-r2 | 65d87ab354 | 334d1d924f | 1\|3 | 3 | yes | semantic | DONE | no | none | ok | e27dc0c34f2c613b0c14b28dfbd895aac973a5c32b30234a3737b2077fc1e980 |
| invbroken-r2 | 65d87ab354 | 334d1d924f | 1\|3 | 3 | yes | semantic | DONE | no | none | ok | fd81a93b52e437623ddb24cf2b81c9f708fb6c7575c4f733d299ea91fa4f01a6 |
| vacuoussecond-r2a | 65d87ab354 | 334d1d924f | 1 | 1 | yes | semantic | DONE | no | none | ok | b024c486e5e7e1f3d864cfeec0b79acaa6307fe8b1f255a2d4c4c2d405982fcf |

Control gate: PASS (control-flag ok, control-siblingok ok, control-flagrenamed ok)
Semantic rejections counted: 0 of 3
