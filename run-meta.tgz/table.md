| case | solar | lean | expect | exit | match | class | kind | stage_ok | replay | producer | certify.log sha256 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| clampwrongspec-r2 |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| control-flag | 92c59b665b | 334d1d924f | 0 | 0 | yes | control | DONE | no | 124 | ok | d40c2f032970467ecb9d36464b51d14ae705bfbe3fc8223034b645016a3b8392 |
| control-flagrenamed | 92c59b665b | 334d1d924f | 0 | 0 | yes | control | DONE | no | 124 | ok | dc919631924b602394d5222a3a93b91258f3767aac7d16fbdf925cddc1f13e01 |
| control-siblingok | 92c59b665b | 334d1d924f | 0 | 0 | yes | control | DONE | no | 124 | ok | 045c439b70ed102a498e2c3456ec36ddb7622815169206b86ece530ab2d79ff0 |
| falseenv |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| flag-branchleak |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| flag-frameleak |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| flag-specwrong | 92c59b665b | 334d1d924f | 1 | 1 | yes | semantic | DONE | yes | none | ok | da3d7b48e454022e1871c860cd18b42273a6caf6c94e976c6f76d38bbf59068e |
| flag-storagealias |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| flag-succeedsalways |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| flag-wrap |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| initbroken-r2 |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| invbroken-r2 |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| meterwrongspec |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| siblingfns-r2 |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| siblingleak | 92c59b665b | 334d1d924f | 1 | 1 | yes | semantic | DONE | yes | none | ok | 5ce6f4bc2e9c8489bcadf7bb868b4e758841aa3f85ffacdbeab3b2d9dc0f039f |
| vacuoussecond-r2a |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| vacuoussecond-r2b |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |

Control gate: FAIL (control-flag no: independent --replay exit '124', control-siblingok no: independent --replay exit '124', control-flagrenamed no: independent --replay exit '124')
Semantic rejections counted: 0 of 2
