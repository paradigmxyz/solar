| case | solar | lean | expect | exit | match | class | kind | stage_ok | replay | producer | certify.log sha256 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| clampwrongspec-r2 |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| control-flag | 65d87ab354 | 334d1d924f | 0 | 0 | yes | control | DONE | yes | skipped-c1 | ok | 738243ed3277e374e94425c0a516c05df4eba180d22a14e1f1c31ad6490d3a16 |
| control-flagrenamed | 65d87ab354 | 334d1d924f | 0 | 0 | yes | control | DONE | yes | skipped-c1 | ok | f21da8fd248790117b1d09db66cd970bc049ef4428a9346ff34bf467b31c2e97 |
| control-siblingok | 65d87ab354 | 334d1d924f | 0 | 0 | yes | control | DONE | yes | skipped-c1 | ok | e2ced86295feff202180632523d8d614776d993d58b6268e5efedf97b8770f18 |
| falseenv |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| flag-branchleak | 65d87ab354 | 334d1d924f | 1 | 1 | yes | semantic | DONE | yes | none | ok | d822972ad6c7af2e6ce3efdacea1ab2963446dfb6ef317ea583d5da98cd11cd4 |
| flag-frameleak | 65d87ab354 | 334d1d924f | 1 | 1 | yes | semantic | DONE | yes | none | ok | f1a4bd2f877b541beb9fbef86e88a838b20f9004461bf555d00aba88205d7ee9 |
| flag-specwrong | 65d87ab354 | 334d1d924f | 1 | 1 | yes | semantic | DONE | yes | none | ok | 67c711a2b9fb3561b363a4aab5004d1741c1f8d153b4422f694292595567a254 |
| flag-storagealias | 65d87ab354 | 334d1d924f | 1 | 1 | yes | semantic | DONE | yes | none | ok | af057ba485831bfa7d67777a0b3180e698937781432196132c06fb02f3d600a7 |
| flag-succeedsalways | 65d87ab354 | 334d1d924f | 1 | 1 | yes | semantic | DONE | no | none | ok | 784ba062905b0bc5391d727de484ac0c573d57b1330b32d636ee37c19ccb2eee |
| flag-wrap |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| initbroken-r2 |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| invbroken-r2 |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| meterwrongspec |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| siblingfns-r2 |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| siblingleak | 65d87ab354 | 334d1d924f | 1 | 1 | yes | semantic | DONE | yes | none | ok | b0c60ac3960625c6e23ab991d9f8b59bf2ad8c9ea605e648b87a5fa7b443b22d |
| vacuoussecond-r2a |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |
| vacuoussecond-r2b |  |  |  |  |  |  | NOT-ADMITTED |  |  |  |  |

Control gate: PASS (control-flag ok, control-siblingok ok, control-flagrenamed ok)
Semantic rejections counted: 5 of 6: flag-branchleak, flag-frameleak, flag-specwrong, flag-storagealias, siblingleak
