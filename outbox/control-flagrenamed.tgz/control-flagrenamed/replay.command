tools/certify/certify --replay /home/ubuntu/run/control-flagrenamed/rec --solidity-lean /home/ubuntu/sl --packages-from /home/ubuntu/pk 
