tools/certify/certify --replay /home/ubuntu/run/control-siblingok/rec --solidity-lean /home/ubuntu/sl --packages-from /home/ubuntu/pk 
