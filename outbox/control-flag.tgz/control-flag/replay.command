tools/certify/certify --replay /home/ubuntu/run/control-flag/rec --solidity-lean /home/ubuntu/sl --packages-from /home/ubuntu/pk 
